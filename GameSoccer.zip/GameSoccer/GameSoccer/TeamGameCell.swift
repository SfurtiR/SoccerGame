//
//  TeamGameCell.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/15/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import UIKit

class TeamGameCell: UITableViewCell {
    
    @IBOutlet weak var teamMatches: UILabel!
}
