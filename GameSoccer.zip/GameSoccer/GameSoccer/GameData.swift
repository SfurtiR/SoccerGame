//
//  GameData.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/14/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import Foundation

class GameData
{
    var id : Int = 0
    var team: String = ""
    var opTeam: String = ""
    var win:Int = 0
    var lose:Int = 0
    var draw:Int = 0
    var total:Int = 0
    
    init(id:Int, team:String,opTeam:String, win:Int,lose: Int,draw: Int, total : Int)
    {
        self.id = id
        self.team = team
        self.opTeam = opTeam
        self.win = win
        self.lose = lose
        self.draw = draw
        self.total = total
    }
}
