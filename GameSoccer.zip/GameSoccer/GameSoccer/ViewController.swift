//
//  ViewController.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/14/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import UIKit
import SQLite3



var db:DBHelper = DBHelper()

class ViewController: UITableViewController {
    
    
    @IBOutlet var gameTable: UITableView!
    
    public var teamName: String? = ""
    weak var delegate: TeamScoreBoard?
    
    
    struct Post:Decodable{
        let AwayScore: Int
        let HomeScore: Int
        let AwayTeamName: String
        let HomeTeamName: String
        
    }
    
    var games:[GameData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        games = db.read(queryStatementString: "SELECT * FROM Game;")
        
    }

    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        
        
        let gameCell = tableView.dequeueReusableCell(withIdentifier: "GameCellID", for: indexPath) as! gameCell
        print(games[indexPath.row].team)
        
        gameCell.teamButton.setTitle(games[indexPath.row].team as! String, for: .normal)
        gameCell.winLabel.text =  String(games[indexPath.row].win)
        gameCell.loseLabel.text = String(games[indexPath.row].lose)
        gameCell.drawLabel.text = String(games[indexPath.row].draw)
        
        var persent = (games[indexPath.row].win) * 100 / (games[indexPath.row].total)
        gameCell.winPerLabel.text = String(persent) + "%"
        
        return gameCell
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return games.count
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 30))
        
        let label = UILabel()
        label.frame = CGRect.init(x: 5, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
        label.text = "Team"
        label.font = .systemFont(ofSize: 16)
        label.textColor = .black
        headerView.backgroundColor = .darkGray
        headerView.addSubview(label)
        
        
        let label1 = UILabel()
        label1.frame = CGRect.init(x: 165, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
        label1.text = "Win"
        label1.font = .systemFont(ofSize: 16)
        label1.textColor = .black
        headerView.backgroundColor = .darkGray
        headerView.addSubview(label1)
        
        
        let label2 = UILabel()
        label2.frame = CGRect.init(x: 205, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
        label2.text = "Lose"
        label2.font = .systemFont(ofSize: 16)
        label2.textColor = .black
        headerView.backgroundColor = .darkGray
        headerView.addSubview(label2)
        
        
        let label3 = UILabel()
        label3.frame = CGRect.init(x: 245, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
        label3.text = "Draw"
        label3.font = .systemFont(ofSize: 16)
        label3.textColor = .black
        headerView.backgroundColor = .darkGray
        headerView.addSubview(label3)
        
        
        let label4 = UILabel()
        label4.frame = CGRect.init(x: 315, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
        label4.text = "Win%"
        label4.font = .systemFont(ofSize: 16)
        label4.textColor = .black
        headerView.backgroundColor = .darkGray
        headerView.addSubview(label4)
        
        return headerView
    }
    override func viewDidAppear(_ animated: Bool)
    {
        tableView.reloadData()
    }
    
    
    @IBAction func teamAction(_ sender: Any) {
        teamName = (sender as! UIButton).titleLabel!.text!
        performSegue(withIdentifier: "teamScore", sender: self)
        
        print("in action")
        print(teamName)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("team")
        print(teamName!)
        
        let controller = segue.destination as! TeamBoard
        controller.teamName = teamName!
        
    }
    
    
    
}

