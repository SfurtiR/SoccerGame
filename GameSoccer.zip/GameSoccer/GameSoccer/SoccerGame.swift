//
//  SoccerGame.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/15/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import UIKit

public struct Game{
    
    var team = ""
    var opTeam = ""
    var win = 0
    var loose = 0
    var draw = 0
    var total = 0
}
public var gameDict = [String:Game]()

class SoccerGame: UIViewController {
    struct Post:Decodable{
        let AwayScore: Int
        let HomeScore: Int
        let AwayTeamName: String
        let HomeTeamName: String
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()
        
    }
    func loadData(){
        
        let urlAsString = "http://l.yimg.com/re/v2/coding_exercise/soccer_data.json"
        var j=1
        let url = URL(string: urlAsString)!
        let urlSession = URLSession.shared
        let task = urlSession.dataTask(with: url){
            data, response, error in
            let decoder = JSONDecoder()

            if let data = data{
                do{
                    let tasks = try decoder.decode([Post].self, from: data)
                    print(tasks)
                    tasks.forEach{ i in
                        var w=0
                        var l = 0
                        var d = 0
                        if i.HomeScore>i.AwayScore{
                                w=1
                        }
                        else{
                            if i.HomeScore<i.AwayScore{
                                    l=1
                            }
                            else{
                                    d=1
                            }
                        }
                        //db.insert(id: j, team: i.HomeTeamName, opTeam: i.AwayTeamName, win: w, lose: l, draw: d, total: 1)
                        j = j+1
                        //
                        var keyExists = gameDict[i.HomeTeamName] != nil
                        if keyExists{
                            var g = gameDict[i.HomeTeamName]
                            if i.AwayTeamName==g?.opTeam{
                                w=w + g!.win
                                l=l+g!.loose
                                d = d + g!.draw
                                
                                let gameData = Game(team: i.HomeTeamName, opTeam: i.AwayTeamName, win: w, loose: l, draw: d, total: 1+g!.total)
                                    gameDict[i.HomeTeamName]=gameData
                            }
                                
                        }
                        else{
                            let gameData = Game(team: i.HomeTeamName, opTeam: i.AwayTeamName, win: w, loose: l, draw: d, total: 1)
                                gameDict[i.HomeTeamName]=gameData
                        }
                            
                        keyExists = gameDict[i.AwayTeamName] != nil
                        if keyExists{
                            var g = gameDict[i.AwayTeamName]
                            if i.HomeTeamName==g?.team{
                                w=w + g!.win
                                l=l+g!.loose
                                d = d + g!.draw
                                
                                let gameData = Game(team: i.AwayTeamName, opTeam: i.HomeTeamName, win: w, loose: l, draw: d, total: 1+g!.total)
                                    gameDict[i.AwayTeamName]=gameData
                            }
                        }
                        else{
                            let gameData = Game(team: i.AwayTeamName, opTeam: i.HomeTeamName, win: w, loose: l, draw: d, total: 1)
                                gameDict[i.AwayTeamName]=gameData
                        }
                        /*
                         
                         
                         */
                    }
                }catch{
                        print(error)
                }
                var i=1
                for (key,value) in gameDict{
                    db.insert(id: i, team: key, opTeam: value.opTeam, win: value.win, lose: value.loose, draw: value.draw, total: value.total)
                    i=i+1
                }
            }
        }
        task.resume()
        
    }
    
}
