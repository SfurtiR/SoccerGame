//
//  gameCell.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/14/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import UIKit

class gameCell: UITableViewCell {
   
    
    @IBOutlet weak var teamButton: UIButton!
    
    @IBOutlet weak var winLabel: UILabel!
    
    @IBOutlet weak var loseLabel: UILabel!
    
    @IBOutlet weak var drawLabel: UILabel!
    
    @IBOutlet weak var winPerLabel: UILabel!
    
    
    
    public var teamSelectedName: String? = ""
    @IBAction func teamSelectionAction(_ sender: Any) {
        
        teamSelectedName = (sender as! UIButton).titleLabel!.text!
        print(teamSelectedName)
    }
    
    
}
