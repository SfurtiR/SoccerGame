//
//  DBHelper.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/14/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import Foundation
import SQLite3

class DBHelper
{
    init()
    {
        db = openDatabase()
        createTable()
    }

    let dbPath: String = "myGameDB.sqlite"
    var db:OpaquePointer?

    func openDatabase() -> OpaquePointer?
    {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent(dbPath)
        var db: OpaquePointer? = nil
        if sqlite3_open(fileURL.path, &db) != SQLITE_OK
        {
            print("error opening database")
            return nil
        }
        else
        {
            print("Successfully opened connection to database at \(dbPath)")
            return db
        }
    }
    
    func createTable() {
        let createTableString = "CREATE TABLE Game(Id INTEGER PRIMARY KEY,team TEXT, opTeam TEXT, win INTEGER, lose INTEGER, draw INTEGER, total INTEGER);"
        var createTableStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) == SQLITE_OK
        {
            if sqlite3_step(createTableStatement) == SQLITE_DONE
            {
                print("Game table created.")
            } else {
                print("Game table could not be created.")
            }
        } else {
            print("CREATE TABLE statement could not be prepared.")
        }
        sqlite3_finalize(createTableStatement)
    }

    func insert(id:Int, team:String, opTeam:String, win:Int,lose:Int, draw:Int, total:Int)
    {
        
        let insertStatementString = "INSERT INTO Game VALUES (?, ?, ?,?,?,?,?);"
        var insertStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == SQLITE_OK {
            sqlite3_bind_int(insertStatement, 1, Int32(id))
            sqlite3_bind_text(insertStatement, 2, (team as NSString).utf8String, -1, nil)
            sqlite3_bind_text(insertStatement, 3, (opTeam as NSString).utf8String, -1, nil)
            sqlite3_bind_int(insertStatement, 4, Int32(win))
            sqlite3_bind_int(insertStatement, 5, Int32(lose))
            sqlite3_bind_int(insertStatement, 6, Int32(draw))
            sqlite3_bind_int(insertStatement, 7, Int32(total))
            
            if sqlite3_step(insertStatement) == SQLITE_DONE {
                print("Successfully inserted row.")
            } else {
                print("Could not insert row.")
            }
        } else {
            print("INSERT statement could not be prepared.")
        }
        sqlite3_finalize(insertStatement)
    }
    
    func read(queryStatementString:String) -> [GameData] {
        //let queryStatementString = "SELECT * FROM Game;"
        var queryStatement: OpaquePointer? = nil
        var gd : [GameData] = []
        if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                let id = sqlite3_column_int(queryStatement, 0)
                let team = String(describing: String(cString: sqlite3_column_text(queryStatement, 1)))
                let opTeam = String(describing: String(cString: sqlite3_column_text(queryStatement, 2)))
                let win = sqlite3_column_int(queryStatement, 3)
                let lose = sqlite3_column_int(queryStatement, 4)
                let draw = sqlite3_column_int(queryStatement, 5)
                let total = sqlite3_column_int(queryStatement, 6)
                gd.append(GameData(id: Int(id), team: team, opTeam: opTeam, win: Int(win), lose: Int(lose), draw: Int(draw), total: Int(total)))
                    
                
            }
        } else {
            print("SELECT statement could not be prepared")
        }
        sqlite3_finalize(queryStatement)
        return gd
    }

}
