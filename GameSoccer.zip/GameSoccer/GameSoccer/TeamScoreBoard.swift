//
//  TeamScoreBoard.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/15/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

protocol TeamScoreBoard: class {
    func teamIs(_ team: String)
}
