//
//  TeamBoard.swift
//  GameSoccer
//
//  Created by Sfurti Khane on 11/15/22.
//  Copyright © 2022 Sfurti Khane. All rights reserved.
//

import UIKit

class TeamBoard: UITableViewController{
    
    @IBOutlet var teamTabelView: UITableView!
    
    var teamName:String = ""
    
    var games:[GameData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("In team")
        print(teamName)
        games = db.read(queryStatementString: "SELECT * FROM Game where team='"+teamName+"';")
        print(games)
        
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 110))
        
        let label = UILabel()
        label.frame = CGRect.init(x: 55, y: 30, width: headerView.frame.width-10, height: 40)
        label.text = teamName
        //label.font = .systemFont(ofSize: 33)
        label.font = .boldSystemFont(ofSize: 33)
        label.textColor = .white
        headerView.backgroundColor = .blue
        headerView.addSubview(label)
        
        teamTabelView.tableHeaderView = headerView
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 110, width: tableView.frame.width, height: 110))
        
        let label = UILabel()
        label.frame = CGRect.init(x: 30, y: 5, width: headerView.frame.width-10, height: 20)
        label.text = "Team Name      W      L     D    T"
        label.font = .systemFont(ofSize: 16)
        label.textColor = .black
        headerView.backgroundColor = .darkGray
        headerView.addSubview(label)
        
        return headerView
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let teamGameCell = tableView.dequeueReusableCell(withIdentifier: "teamMatchId", for: indexPath) as! TeamGameCell
        print(games[indexPath.row].team)
        
        teamGameCell.teamMatches.text = games[indexPath.row].opTeam + "    "+String(games[indexPath.row].win)+"    "+String(games[indexPath.row].lose)+"    "+String(games[indexPath.row].draw)+"    "+String(games[indexPath.row].total)

        
        return teamGameCell
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return games.count
    }
}
